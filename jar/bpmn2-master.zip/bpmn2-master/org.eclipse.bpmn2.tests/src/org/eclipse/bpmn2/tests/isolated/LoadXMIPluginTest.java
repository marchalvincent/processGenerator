package org.eclipse.bpmn2.tests.isolated;

public class LoadXMIPluginTest extends LoadXMLPluginTest {
    protected String getFilename() {
        return "res/basic.bpmn2xmi";
    };
}
