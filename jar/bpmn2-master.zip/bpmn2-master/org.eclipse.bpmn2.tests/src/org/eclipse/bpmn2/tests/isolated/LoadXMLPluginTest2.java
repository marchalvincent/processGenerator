package org.eclipse.bpmn2.tests.isolated;

/**
 * Arbitrary extension.
 * @author Henning Heitkoetter
 *
 */
public class LoadXMLPluginTest2 extends LoadXMLPluginTest {
    protected String getFilename() {
        return "res/basic.xml";
    };
}
